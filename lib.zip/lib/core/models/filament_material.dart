enum FilamentMaterial {
  pla,
  petg,
  abs,
  tpu,
  nylon,
  other,
}
